BHUMI MOBILE & ELECTRONICS — ANDROID OFFLINE PROJECT

यह Android Studio/AndroidIDE project source है, तैयार APK नहीं।

मुख्य बातें:
- HTML ऐप app/src/main/assets/index.html में शामिल है।
- ऐप ऑफलाइन चलेगा; डेटा इसी ऐप के WebView local storage में सेव होगा।
- Backup JSON ऐप के Documents app-folder में सेव होता है।
- Restore के लिए ऐप का JSON file picker इस्तेमाल होता है।

APK बनाने के लिए:
1. Android Studio या AndroidIDE में इस project folder को खोलें।
2. Gradle sync पूरा होने दें।
3. Build > Build APK(s) चुनें।
4. APK app/build/outputs/apk/debug/app-debug.apk में बनेगा।

महत्वपूर्ण:
- APK इंस्टॉल करने के बाद पुराने Chrome/Ship.page वाले डेटा अपने आप इस ऐप में नहीं आएँगे।
- पुराने वेब ऐप से JSON backup export करें। इस Android ऐप में Backup tab > JSON file चुनकर Restore करें।
- फोन बदलने या ऐप uninstall करने से पहले Backup जरूर लें।
